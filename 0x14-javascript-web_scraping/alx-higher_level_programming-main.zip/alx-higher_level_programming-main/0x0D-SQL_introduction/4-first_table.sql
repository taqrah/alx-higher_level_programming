-- Creates a table called first_table with values id and name in my MySQL server.
CREATE TABLE IF NOT EXISTS `first_table` (`id` INT, `name` VARCHAR(256));
