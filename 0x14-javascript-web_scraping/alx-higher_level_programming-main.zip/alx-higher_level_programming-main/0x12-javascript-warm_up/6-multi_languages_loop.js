#!/usr/bin/node
for (const line of ['C is fun', 'Python is cool', 'JavaScript is amazing']) {
  console.log(line);
}
