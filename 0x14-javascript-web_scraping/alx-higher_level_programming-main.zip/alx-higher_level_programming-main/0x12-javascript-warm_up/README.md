JavaScript - Warm up

This project gives me an understanding of the basics of JavaScript as it relates to Sripting and Web front-end.

0-javascript_is_amazing.js - Writes a script that prints “JavaScript is amazing”.

1-multi_languages.js - Writes a script that prints 3 lines:

The first line: “C is fun”
The second line: “Python is cool”
The third line: “JavaScript is amazing”

2-arguments.js - Writes a script that prints a message depending of the number of arguments passed.

3-value_argument.js - Writes a script that prints the first argument passed to it.

4-concat.js - Writes a script that prints two arguments passed to it, in the following format: “ is ”

5-to_integer.js - Writes a script that prints My number: <first argument converted in integer> if the first argument can be converted to an integer.

6-multi_languages_loop.js - Writes a script that prints 3 lines: (like 1-multi_languages.js) but by using an array of string and a loop

The first line: “C is fun”
The second line: “Python is cool”
The third line: “JavaScript is amazing”.

7-multi_c.js - Writes a script that prints x times “C is fun”.

8-square.js - Writes a script that prints a square.

9-add.js - Writes a script that prints the addition of 2 integers

The first argument is the first integer
The second argument is the second integer.

10-factorial.js - Writes a script that computes and prints a factorial

The first argument is integer (argument can be cast as integer) used for computing the factorial
Factorial of NaN is 1.

11-second_biggest.js - Writes a script that searches the second biggest integer in the list of arguments.

12-object.js - Updates a given script to replace the value 12 with 89.

13-add.js - Writes a function that returns the addition of 2 integers.

100-let_me_const.js - Writes a file that modifies the value of myVar to 333.

101-call_me_moby.js - Writes a function that executes x times a function.

102-add_me_maybe.js - Writes a function that increments and calls a function.

103-object_fct.js - Updates a given script by adding a new function incr that increments the integer value.  

