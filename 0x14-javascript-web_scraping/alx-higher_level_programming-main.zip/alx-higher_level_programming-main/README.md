This repo marks the beginning of my journey in Python Programming in the 2022 ALX Cohort 9 Software Engineering Programme. Further description will be added as I progress in my learning
