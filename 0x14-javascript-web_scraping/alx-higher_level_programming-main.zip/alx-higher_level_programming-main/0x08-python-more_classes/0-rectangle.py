#!/usr/bin/python3
"""
Defining an empty class Rectangle
"""


class Rectangle:
    """Empty representation of a Rectangle"""
    pass
