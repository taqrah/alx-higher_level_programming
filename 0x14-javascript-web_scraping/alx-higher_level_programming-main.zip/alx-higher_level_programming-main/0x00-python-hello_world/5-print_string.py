#!/usr/bin/python3
str = "Holberton School"
print("{}".format(str) * 3)
print(str[:9])
