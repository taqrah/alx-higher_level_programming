This is a Python - Test-driven development Project. The project is aimed at providing an understanding of the interactive test, Docstrings, Module documentation, and the Importance of Test in Python programming
The files below executes the following function;

0-add_integer.py - Writes a function that adds 2 integers.

2-matrix_divided.py - Writes a function that divides all elements of a matrix.

3-say_my_name.py - Writes a function that prints My name is <first name> <last name>

4-print_square.py - Writes a function that prints a square with the character #.

5-text_indentation.py a function that prints a text with 2 new lines after each of these characters: ., ? and :

6-max_integer_test.py d - Writes a unittests for the function def max_integer(list=[]):

100-matrix_mul.py - Writes a function that multiplies 2 matrices:

101-lazy_matrix_mul.py - Writes a function that multiplies 2 matrices by using the module NumPy.

102-python.c - Creates a function that prints Python strings.

All the test files are contained in the "test" folder.
