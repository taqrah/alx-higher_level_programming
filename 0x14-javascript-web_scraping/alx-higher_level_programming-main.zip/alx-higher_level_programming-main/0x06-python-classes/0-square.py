#!/usr/bin/python3

"""Define a class square"""


class Square:
    """reapting a square"""
    pass
