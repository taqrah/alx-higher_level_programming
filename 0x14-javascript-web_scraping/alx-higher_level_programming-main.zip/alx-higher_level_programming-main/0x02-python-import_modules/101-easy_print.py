#!/usr/bin/python3
exec('import subprocess; subprocess.call(["echo", "#pythoniscool"])')
