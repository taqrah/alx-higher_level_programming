This project focuses on the use of Python Modules and the Importation of functions with command line arguments using Python programs.
The file programs are executed thus;

0 - Writes a program that imports the function def add(a, b): from the file add_0.py and prints the result of the addition 1 + 2 = 3.

1 - Writes a program that imports functions from the file calculator_1.py, does some Maths, and prints the result.

2 - Writhes a program that prints the number of and the list of its arguments.

3 - Writes a program that prints the result of the addition of all arguments.

4 - Writes a program that prints all the names defined by a given compiled module.

5 - Writes a program that imports the variable a from a given file and prints its value.

6 - Writes a program that imports all functions from a given file and handles basic operations.

7 - Writes program that prints #pythoniscool, followed by a new line, in the standard output.

8 - Writes the Python function def magic_calculation(a, b): that does exactly the same as a given Python bytecode.

9 - Writes a program that prints the alphabet in uppercase, followed by a new line.

