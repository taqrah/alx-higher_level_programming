#!/usr/bin/python3
if __name__ == "__main__":
    import variable_load_5
    print(variable_load_5.a)
