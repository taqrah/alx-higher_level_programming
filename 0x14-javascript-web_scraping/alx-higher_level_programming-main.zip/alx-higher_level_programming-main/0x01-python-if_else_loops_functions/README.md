This Project dwells on the use and application of the "if/else, loops, functions and operators" in Python programming.
Programs in the respective files are declared to execute the following functions;

0 - Writes a program that will assign a random signed number to the variable number in a given lines of code each time it is executed.

1 - Writes a program That will assign a random signed number to the variable number each time it is executed.

2 - Writes a program that prints the ASCII alphabet, in lowercase, not followed by a new line.

3 - Writes a program that prints the ASCII alphabet, in lowercase, not followed by a new line
 and prints all the letters except q and e.

4 - Writes a program that prints all numbers from 0 to 98 in decimal and in hexadecimal.

5 - Writes a program that prints numbers separated by "," from 0 to 99 in an ascending order.

6 - Writes a program that prints all possible different combinations of two digits separated by "," in an ascending order.

7 - Writes a function that checks for lowercase character in a givern program and returns True if c is lowercase. Returns False otherwise.

8 - Writes a function that prints a string in uppercase followed by a new line.

9 - Writes a function that prints the last digit of a number.

10 - Writes a function that adds two integers and returns the result.

11 - Write a function that computes a to the power of b and return the value.

12 - Writes a function that prints the numbers from 1 to 100 separated by a space.
* For multiples of three print Fizz instead of the number and for multiples of five print Buzz.
* For numbers which are multiples of both three and five print FizzBuzz.

13 - Writes a function in C that inserts a number into a sorted singly linked list and returns the address of the new node, or NULL if it faileds.

14 - Writes a program that prints the ASCII alphabet, in reverse order, alternating lowercase and uppercase (z in lowercase and Y in uppercase), not followed by a new line.

15 - Writes a function that creates a copy of the string, removing the character at the position n (not the Python way, the “C array index”).

16 - Writes the Python function def magic_calculation(a, b, c): that does exactly the same as a given Python bytecode:

The prototypes of all the C files are stored in the lists.h file.
