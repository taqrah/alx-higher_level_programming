#!/usr/bin/python3
# Author - Solomon Iniodu

def pow(a, b):
    return (a ** b)
