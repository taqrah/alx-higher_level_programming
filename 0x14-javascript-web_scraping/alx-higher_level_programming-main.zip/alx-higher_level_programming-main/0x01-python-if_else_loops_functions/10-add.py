#!/usr/bin/python3
# Author - Solomon Iniodu
def add(a, b):
    """Return the addition of a and b."""
    return (a + b)
