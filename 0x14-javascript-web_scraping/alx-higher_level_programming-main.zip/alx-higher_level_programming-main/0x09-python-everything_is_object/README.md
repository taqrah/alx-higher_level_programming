Python - OOP - Everything is object.
This project is a little bit different than the usual projects. The first part is only questions about Python’s specificity like “What would be the result of…”. 
The link below describes the entire project, the files and functions to be executed by each file.
https://alx-intranet.hbtn.io/projects/252.
