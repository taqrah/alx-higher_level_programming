#!/bin/bash
# Display only body of 200 status code response using curl
curl -sL "$1"
