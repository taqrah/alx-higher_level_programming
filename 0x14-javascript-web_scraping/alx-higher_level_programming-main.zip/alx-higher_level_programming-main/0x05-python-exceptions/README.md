This project focuses on Python - Exceptions and Error. The files executes the following functions;

0 - Writes  a function that prints x elements of a list.
1 - Writes a function that prints an integer with "{:d}".format().
2 - Writes a function that prints the first x elements of a list and only integers.
3 - Writes a function that divides 2 integers and prints the result.
4 - Writes a function that divides element by element 2 lists.
5 - Wites a function that raises a type exception.
6 - Writes a function that raises a name exception with a message.
100 - Writes a function that prints an integer.
101 - Writes a function that executes a function safely.
102 Writes the Python function def magic_calculation(a, b): that does exactly the same as a given Python bytecode.
103 - Creates three C functions that print some basic info about Python lists, Python bytes an Python float objects.

