Python - Almost a circle.

This project covers Python;
-Import
-Exceptions
-Class
-Private attribute
-Getter/Setter
-Class method
-Static method
-Inheritance
-Unittest
-Read/Write file

As well as;
-args and kwargs
-Serialization/Deserialization
-JSON

All test files are python files (extension: .py) and are compiled in the "tests" folder.
All test files and folders starts with "test_".
All file organization in the tests folder are the same as project: ex: for models/base.py, unit tests are in: tests/test_models/test_base.py
