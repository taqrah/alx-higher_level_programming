JavaScript - Objects, Scopes and Closures.

In this project, I learned the following;

JavaScript object basics
Object-oriented JavaScript (read all examples!)
Class - ES6
super - ES6
extends - ES6
Object prototypes
Inheritance in JavaScript
Closures
this/self
Modern JS

The files below where created to uptput the following functions;

0-rectangle.js - Writes an empty class Rectangle that defines a rectangle:

1-rectangle.js - Writes a class Rectangle that defines a rectangle.

2-rectangle.js - Writes a class Rectangle that defines a rectangle.

3-rectangle.js - Writes a class Rectangle that defines a rectangle.

4-rectangle.js - Writes a class Rectangle that defines a rectangle.

5-square.js - Writes a class Square that defines a square and inherits from Rectangle of 4-rectangle.js.

6-square.js - Writes a class Square that defines a square and inherits from Square of 5-square.js.

7-occurrences.js - Writes a function that returns the number of occurrences in a list.

8-esrever.js - Writes a function that returns the reversed version of a list.

9-logme.js - Writes a function that prints the number of arguments already printed and the new argument value.

10-converter.js - Writes a function that converts a number from base 10 to another base passed as argument.

100-map.js - Writes a script that imports an array and computes a new array.

101-sorted.js - Writes a script that imports a dictionary of occurrences by user id and computes a dictionary of user ids by occurrence.

